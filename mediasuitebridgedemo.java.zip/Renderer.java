// -------------------- BRIDGE PATTERN --------------------r.java
interface Renderer {
    void render(String mediaData);
}