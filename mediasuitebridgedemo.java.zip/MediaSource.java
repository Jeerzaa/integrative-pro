// -------------------- ADAPTER PATTERN --------------------
interface MediaSource {
    String fetch();
}
