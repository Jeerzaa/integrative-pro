interface Media {
    void play();
}